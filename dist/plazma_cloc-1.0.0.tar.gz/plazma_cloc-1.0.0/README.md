# cloc

## Description
cloc (Count LOC) is a simple terminal utility to easily count lines of code in a file / project. 

## Installation
### Windows, Linux & Mac
1. Make sure you have a recent version of Python installed.
2. Run the command `pip install plazma-cloc` to install.
3. Done.

## Usage
1. Open a terminal and run the command `cloc <PATH_TO_FILE_OR_PROJECT>`
2. For help run the command `cloc -h`

To narrow the file types down use the `--ignore` flag.
This flag allows you to ignore certain files, directories and file extensions.

### Ignoring singular files
To ignore one file use `cloc your_project_folder --ignore your_file.txt`

You can also ignore multiple files with this same syntax.

E.G. `cloc your_project_folder --ignore "your_file.txt" "your_other_file.txt"`

> Note: It is good practice to surround each file / directory / extension in quotation marks to avoid your terminal getting confused

### Ignoring singular directories
To ignore one directory use `cloc your_project_folder --ignore your_directory`

You can also ignore multiple directories with this same syntax.

E.G. `cloc your_project_folder --ignore "your_directory" "your_other_directory"`

### Ignoring files with certain file extensions
To ignore all files with a certain file extension use `cloc your_project_folder --ignore "*.txt"

The '*' character is a wildcard character and tells the program it means every file with the file extension after the wildcard.

Then after the wildcard you enter the file extension. E.G. ".txt" or ".exe"...

You can also ignore multiple file extensions with the same syntax as before.
`cloc your_project_folder --ignore "*.txt" "*.exe" "*.json"`

### Ignoring all directories with the same name
To ignore all directories with the same name use a similar ignore pattern as before:
`cloc your_project_folder --ignore your_directory/*`

You must append `/*` to the end of the directory name so that the program knows it is a recursive directory ignore.

You can ignore multiple directories using a similar command:
`cloc your_project_folder --ignore "your_directory/*" "your_other_directory/*"`

